﻿using System.IO;
using System.Reflection;
using System.Configuration;
using System.Security.Cryptography.X509Certificates;
using WebSocketSharp.Server;
using System.ServiceProcess;
using log4net;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", Watch = true)]
namespace ConnectorWebSocket
{
    public partial class Service : ServiceBase
    {
        public static ILog log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        private WebSocketServer wsServerSSL = null;
        private SATO.Crypto crypto = new SATO.Crypto();
        public Service()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            log.Info("Services Starting");
            try
            {
#if DEBUG
                wsServerSSL = new WebSocketServer(8080, false);
#else

                var cert = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), ConfigurationManager.AppSettings["certFile"]).ToString();
                var password = ConfigurationManager.AppSettings["certPassword"];
                wsServerSSL = new WebSocketServer(8443, true);
                wsServerSSL.SslConfiguration.ServerCertificate = new X509Certificate2(cert, crypto.DecryptData(password));
                wsServerSSL.SslConfiguration.EnabledSslProtocols = System.Security.Authentication.SslProtocols.Tls12;
#endif
                wsServerSSL.KeepClean = false;
                wsServerSSL.AddWebSocketService<AEPConnector>("/aepconnector");
                wsServerSSL.Start();
            }
            catch (System.Exception ex)
            {
                log.Info(string.Format("Exceptional, {0}", ex.Message));
            }
            log.Info("Services Started");

            base.OnStart(args);
        }

        protected override void OnStop()
        {
            log.Info("Services Stopping");
            if (wsServerSSL != null)
            {
                wsServerSSL.Stop();
                wsServerSSL = null;
            }
            base.OnStop();
        }

        protected override void OnShutdown()
        {
            log.Info("System ShutDown");
            if (wsServerSSL != null)
            {
                wsServerSSL.Stop();
                wsServerSSL = null;
            }
            base.OnShutdown();
        }
    }
}
