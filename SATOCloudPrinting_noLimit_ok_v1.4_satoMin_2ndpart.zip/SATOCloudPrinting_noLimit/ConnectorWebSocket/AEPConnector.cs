﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using WebSocketSharp;
using WebSocketSharp.Server;

namespace ConnectorWebSocket
{
    public class AEPConnector : WebSocketBehavior
    {
        private static Dictionary<string, WSClientInfo> WSClients = new Dictionary<string, WSClientInfo>();
        private static System.Timers.Timer LSTimer = null;
        private static WebSocketSessionManager sess = null;

        public class PrinterStatusResponse
        {
            public int PrinterStatus;
            public int ReceiveBuffeStatus;
            public int ErrorNo;
        }

        protected override void OnMessage(MessageEventArgs e)
        {
            var wsInfo = WSClients.Where(x => x.Key == ID).Select(p => p.Value).FirstOrDefault();
            if (wsInfo != null)
            {
                wsInfo.Active = true;
                wsInfo.LastSeen = DateTime.UtcNow;
            }

            if (e.IsPing) { } //do nothing for ping, it just updating the last seen datatime
            else
            {
                try
                {
                    if (e.IsText)
                    {
                        var returnVal = ProcessMessage(e.Data);
                        if (returnVal != null)
                        {
                            foreach (string val in returnVal)
                                Send(val);
                        }
                    }
                    else if (e.IsBinary)
                    {
                        var returnVal = ProcessMessage(Encoding.UTF8.GetString(e.RawData));
                        if (returnVal != null)
                        {
                            foreach (string val in returnVal)
                                Send(Encoding.UTF8.GetBytes(val));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Service.log.Info(string.Format("OnMessage exception, {0}", ex.Message));
                }
            }
        }

        private List<string> ProcessMessage(string message)
        {
            ConnectorData connData = null;
            try
            {
                //Service.log.Info("ProcessMessage: " + message);
                string[] splitString = message.Split(',');
                StringBuilder sb = new StringBuilder();

                for (int i = 0; i < splitString.Length; i++)
                {
                    string dataString = '"' + "Data" + '"' + ":";
                    if (!splitString[i].Contains(dataString))
                    {
                        if (i == 0)
                            sb.Append(splitString[i]);
                        else
                            sb.Append("," + splitString[i]);
                    }
                }

                if (!sb.ToString().EndsWith("}"))
                    sb.Append("}");

                Service.log.Info("ProcessMessage: " + sb.ToString());

                connData = JsonConvert.DeserializeObject<ConnectorData>(message);
            }
            catch { }

            if (connData == null)
                return new List<string> { ReturnVal.ServiceUnavailable };

            else if (connData.WebAPIServer != null)
            {
                connData.WebAPIServer = null;
                var dataType = connData.DataType;
                connData.DataType = null;
                List<string> connIds = null;

                if (connData.SendToMAC == null)
                    connIds = Sessions.IDs.Where(x => x != ID).ToList();
                else
                {
                    var filterNullPrinter = WSClients.Where(x => x.Value.Printer != null).ToList();
                    connIds = filterNullPrinter.Where(x => x.Value.Printer.MacAddress == connData.SendToMAC).Select(p => p.Key).ToList();
                }
                return APIServerMsg(connData, dataType, connIds);
            }
            else
            {
                return ConnectorMsg(connData);
            }
        }

        private bool WSSendMsg(string msg, string dataType, string id)
        {
            var exist = Sessions.IDs.Where(x => x == id).FirstOrDefault();
            if (exist != null)
            {
                if (dataType != null && dataType.ToUpper() == "STRING")
                    Sessions.SendTo(msg, id);
                else
                    Sessions.SendTo(Encoding.UTF8.GetBytes(msg), id);

                return true;
            }
            else
                return false;
        }

        private List<string> APIServerMsg(ConnectorData connData, string dataType, List<string> connIds)
        {
            if (connData.Action.ToUpper() == ConnectorAction.SendCommand
                || connData.Action.ToUpper() == ConnectorAction.GetPrinterStatus || connData.Action.ToUpper() == ConnectorAction.GetResendPrinterStatus
                || connData.Action.ToUpper() == ConnectorAction.UpdatePackage || connData.Action.ToUpper() == ConnectorAction.SendPrintCommand
                || connData.Action.ToUpper() == ConnectorAction.ResendPrintCommand)
            {
                if (connIds.Count == 1)
                {
                    bool printerRegistered = false;
                    using (var db = new SATOCloudDBEntities())
                    {
                        var printer = db.Printers.Where(x => x.MACAddress.ToUpper() == connData.SendToMAC.ToUpper()).FirstOrDefault();
                        if (printer != null)
                            printerRegistered = (bool)printer.Registered;
                    }

                    if (printerRegistered)
                    {
                        connData.ServerID = ID;
                        connData.SendToMAC = null;

                        if (connData.Action.ToUpper() == ConnectorAction.ResendPrintCommand)
                        {
                            //PrintSpooler printSpoolers = null;
                            PrintSpoolersData printData = null;

                            using (var db = new SATOCloudDBEntities())
                            {
                                int printSpoolerID = Int32.Parse(connData.PrintSpoolerId);
                                //printSpoolers = db.PrintSpoolers.Where(x => x.PrintSpoolerId == printSpoolerID).FirstOrDefault();
                                printData = db.PrintSpoolersDatas.Where(y => y.PrintSpoolerId == printSpoolerID).FirstOrDefault();

                                //if (printSpoolers != null && printData != null)
                                if (printData != null)
                                {
                                    byte[] binaryString = (byte[])printData.PrintData;

                                    connData.Data = Convert.ToBase64String(binaryString); //printSpoolers.PrintData;
                                    connData.DataSize = printData.PrintDataSize;
                                }
                            }
                        }

                        string json = JsonConvert.SerializeObject(connData, new JsonSerializerSettings
                        {
                            NullValueHandling = NullValueHandling.Ignore
                        });
                        WSSendMsg(json, dataType, connIds[0]);
                        return null;
                    }
                }
                return new List<string> { ReturnVal.ServiceUnavailable };
            }
            else if (connData.Action.ToUpper() == ConnectorAction.RegisterDevice)
            {
                using (var db = new SATOCloudDBEntities())
                {
                    Printer printer;

                    if (connData.AuthCode == "" || connData.AuthCode == null) //RegisterDevice
                    {
                        printer = new Printer();
                        printer.PrinterName = connData.PrinterName;
                        printer.Model = connData.Model;
                        printer.Serial = connData.Serial;
                        printer.Active = true;
                        printer.Registered = false;
                        printer.CreatedBy = "WebAPI";
                        printer.CreatedDT = DateTime.Now;

                        db.Printers.Add(printer);
                        db.SaveChanges();

                        return new List<string> { ReturnVal.Accepted };
                    }
                    else //Auth Device
                    {
                        printer = db.Printers.Where(x => x.AuthCode == connData.AuthCode
                        && x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()))
                        .FirstOrDefault();

                        if (printer != null)
                        {
                            printer.PrinterName = connData.PrinterName;
                            printer.AuthCode = null;
                            printer.Registered = true;
                            printer.Active = true;
                            printer.UpdatedDT = DateTime.UtcNow;
                            printer.UpdatedBy = "WebAPI";
                            db.SaveChanges();

                            var filterNullPrinter = WSClients.Where(x => x.Value.Printer != null).ToList();
                            connIds = filterNullPrinter.Where(x => x.Value.Printer.MacAddress == printer.MACAddress).Select(p => p.Key).ToList();
                            foreach (string id in connIds)
                            {
                                ConnectorData replyDMP = new ConnectorData();
                                replyDMP.Action = ConnectorAction.DisplayMessage;
                                replyDMP.ServerID = "NA";
                                replyDMP.Title = "REGISTERED";

                                string json = JsonConvert.SerializeObject(replyDMP, new JsonSerializerSettings
                                {
                                    NullValueHandling = NullValueHandling.Ignore

                                });
                                WSSendMsg(json, dataType, id);
                            }
                            return new List<string> { ReturnVal.Accepted };
                        }
                        else
                            return new List<string> { ReturnVal.ServiceUnavailable };
                    }
                }
            }
            else if (connData.Action.ToUpper() == ConnectorAction.DeregisterDevice)
            {
                using (var db = new SATOCloudDBEntities())
                {
                    var printer = db.Printers.Where(x => x.MACAddress.ToUpper() == connData.MACAddress.ToUpper()
                    && x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()))
                    .FirstOrDefault();

                    if (printer != null)
                    {
                        string authCode = null;
                        while (true)
                        {
                            authCode = RandomNumber(0, 9999).ToString("0000");
                            var exist = db.Printers.Where(x => x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()) && x.AuthCode == authCode).FirstOrDefault();
                            if (exist == null)
                                break;
                        }
                        printer.AuthCode = authCode;
                        printer.Registered = false;
                        printer.Active = true;
                        printer.UpdatedDT = DateTime.UtcNow;
                        printer.UpdatedBy = "WebAPI";
                        db.SaveChanges();

                        var filterNullPrinter = WSClients.Where(x => x.Value.Printer != null).ToList();
                        connIds = filterNullPrinter.Where(x => x.Value.Printer.MacAddress.ToUpper() == printer.MACAddress.ToUpper()).Select(p => p.Key).ToList();
                        foreach (string id in connIds)
                        {
                            ConnectorData replyDMP = new ConnectorData();
                            replyDMP.Action = ConnectorAction.DisplayMessage;
                            replyDMP.ServerID = "NA";
                            replyDMP.Title = "AUTHENTICATION";
                            replyDMP.Content = "Code: " + printer.AuthCode + "<br /><br />Printer S/N: " + printer.Serial;

                            string json = JsonConvert.SerializeObject(replyDMP, new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore

                            });
                            WSSendMsg(json, dataType, id);
                        }
                        return new List<string> { ReturnVal.Accepted };
                    }
                    else
                        return new List<string> { ReturnVal.ServiceUnavailable };
                }
            }
            else if (connData.Action.ToUpper() == ConnectorAction.DeleteRegisterDevice)
            {
                using (var db = new SATOCloudDBEntities())
                {
                    Printer printer = null;

                    if (connData.MACAddress != "" && connData.MACAddress != null)
                        printer = db.Printers.Where(x => x.MACAddress.ToUpper() == connData.MACAddress.ToUpper()
                        && x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()))
                        .FirstOrDefault();
                    else if (connData.Model != "" && connData.Model != null &&
                             connData.PrinterName != "" && connData.PrinterName != null)
                        printer = db.Printers.Where(x => x.PrinterName.ToUpper() == connData.PrinterName.ToUpper()
                        && x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()))
                        .FirstOrDefault();

                    if (printer != null)
                    {
                        db.Printers.Remove(printer);
                        db.SaveChanges();

                        return new List<string> { ReturnVal.Accepted };
                    }
                    else
                        return new List<string> { ReturnVal.ServiceUnavailable };
                }
            }
            //else if (connData.Action.ToUpper() == ConnectorAction.GetRegisterDevice)
            //{
            //    List<Printer> printers = null;
            //    using (var db = new SATOCloudDBEntities())
            //    {
            //        printers = db.Printers.Where(x=> x.Active == true).ToList();
            //        //printers = db.Printers.Where(x => x.Registered == true && x.Active == true).ToList();
            //    }
            //    if (printers != null & printers.Count > 0)
            //    {
            //        return new List<string> { JsonObjReturn(printers.OrderBy(x => x.Model).ThenBy(y => y.PrinterName)) };
            //    }
            //    else
            //    {
            //        return new List<string> { ReturnVal.ServiceUnavailable };
            //    }
            //}
            //else if (connData.Action.ToUpper() == ConnectorAction.GetPrinterModel)
            //{
            //    List<PrinterModel> printers = null;
            //    using (var db = new SATOCloudDBEntities())
            //    {
            //        printers = db.PrinterModels.ToList();
            //    }
            //    if (printers != null & printers.Count > 0)
            //    {
            //        return new List<string> { JsonObjReturn(printers.OrderBy(x => x.Model)) };
            //    }
            //    else
            //    {
            //        return new List<string> { ReturnVal.ServiceUnavailable };
            //    }
            //}
            //else if (connData.Action.ToUpper() == ConnectorAction.GetPrintSpooler)
            //{
            //    List<PrintSpooler> printSpoolers = null;
            //    using (var db = new SATOCloudDBEntities())
            //    {
            //        printSpoolers = db.PrintSpoolers.ToList();
            //    }
            //    if (printSpoolers != null & printSpoolers.Count > 0)
            //    {
            //        return new List<string> { JsonObjReturn(printSpoolers.OrderBy(x => x.MACAddress).ThenBy(y => y.PrintSpoolerId)) };
            //    }
            //    else
            //    {
            //        return new List<string> { ReturnVal.ServiceUnavailable };
            //    }
            //}
            //else if (connData.Action.ToUpper() == ConnectorAction.AddPrintSpooler)
            //{
            //    using (var db = new SATOCloudDBEntities())
            //    {
            //        var printSpooler = new PrintSpooler();
            //        var psData = new PrintSpoolersData();
            //        ConnectorData replyConnData = new ConnectorData();

            //        try
            //        {
            //            var printer = db.Printers.Where(x => x.MACAddress == connData.SendToMAC.ToUpper()).FirstOrDefault();

            //            printSpooler.PrinterName = printer.PrinterName;
            //            printSpooler.MACAddress = connData.SendToMAC.ToUpper();
            //            printSpooler.DocumentName = connData.DocumentName;
            //            printSpooler.PrintDateTime = DateTime.Now;

            //            db.PrintSpoolers.Add(printSpooler);
            //            db.SaveChanges();

            //            psData.PrintSpoolerId = printSpooler.PrintSpoolerId;
            //            psData.PrintData = connData.PrintData;
            //            psData.PrintDataSize = connData.PrintDataSize;
            //            db.PrintSpoolersDatas.Add(psData);
            //            db.SaveChanges();
            //        }
            //        catch (DbEntityValidationException e)
            //        {
            //            foreach (var eve in e.EntityValidationErrors)
            //            {
            //                Service.log.Error(String.Format("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
            //                    eve.Entry.Entity.GetType().Name, eve.Entry.State));
            //                foreach (var ve in eve.ValidationErrors)
            //                {
            //                    Service.log.Error(String.Format("- Property: \"{0}\", Error: \"{1}\"",
            //                        ve.PropertyName, ve.ErrorMessage));
            //                }
            //            }
            //            throw;
            //        }

            //        replyConnData.Result = ReturnVal.Accepted;
            //        return new List<string> { ReturnVal.Accepted };
            //    }
            //}
            //else if (connData.Action.ToUpper() == ConnectorAction.DeletePrintSpooler)
            //{
            //    using (var db = new SATOCloudDBEntities())
            //    {
            //        ConnectorData replyConnData = new ConnectorData();

            //        try
            //        {
            //            var printSpoolerIdArray = connData.PrintSpoolerId.Split(',');

            //            for (int i = 0; i < printSpoolerIdArray.Length; i++)
            //            {
            //                int printSpoolerId = Int32.Parse(printSpoolerIdArray[i].ToString());
            //                var printSpooler = db.PrintSpoolers.Where(x => x.PrintSpoolerId == printSpoolerId).FirstOrDefault();
            //                var psData = db.PrintSpoolersDatas.Where(x => x.PrintSpoolerId == printSpoolerId).FirstOrDefault();

            //                db.PrintSpoolers.Remove(printSpooler);
            //                db.PrintSpoolersDatas.Remove(psData);

            //                db.SaveChanges();
            //            }

            //            replyConnData.Result = ReturnVal.Accepted;
            //            return new List<string> { ReturnVal.Accepted };
            //        }
            //        catch (DbEntityValidationException e)
            //        {
            //            foreach (var eve in e.EntityValidationErrors)
            //            {
            //                Service.log.Error(String.Format("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
            //                    eve.Entry.Entity.GetType().Name, eve.Entry.State));
            //                foreach (var ve in eve.ValidationErrors)
            //                {
            //                    Service.log.Error(String.Format("- Property: \"{0}\", Error: \"{1}\"",
            //                        ve.PropertyName, ve.ErrorMessage));
            //                }
            //            }
            //            return new List<string> { ReturnVal.ServiceUnavailable };
            //            throw;
            //        }
            //    }
            //}
            else
                return new List<string> { ReturnVal.ServiceUnavailable };
        }

        private List<string> ConnectorMsg(ConnectorData connData)
        {
            if (connData.Action.ToUpper() == ConnectorAction.RegisterPrinterInfo)
            {
                var conn = WSClients.Where(x => x.Key == ID).Select(p => p.Value).FirstOrDefault();
                if (conn != null && connData.MACAddress != null)
                {
                    conn.Printer = new PrinterInfo();
                    conn.Printer.MacAddress = connData.MACAddress.ToUpper();
                    conn.Printer.Firmware = connData.Firmware;
                    conn.Printer.Model = connData.Model;
                    conn.Printer.Serial = connData.Serial;

                    using (var db = new SATOCloudDBEntities())
                    {
                        var printer = db.Printers.Where(x => x.MACAddress.Trim().ToUpper() == connData.MACAddress.Trim().ToUpper()
                        && x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()))
                        .FirstOrDefault();

                        if (printer != null)
                        {
                            ConnectorData replyConnData = new ConnectorData();
                            replyConnData.Action = ConnectorAction.RegisterPrinterInfo;

                            printer.Model = connData.Model.ToUpper().Contains("SATO ") ? connData.Model : "SATO " + connData.Model;
                            printer.Serial = connData.Serial;
                            printer.Firmware = connData.Firmware;
                            db.SaveChanges();

                            if ((bool)printer.Registered)
                            {
                                replyConnData.Result = "REGISTERED";
                                return new List<string> { ConnectorDataReturn(replyConnData) };
                            }
                            else
                            {
                                replyConnData.Result = "AUTHENTICATION";
                                ConnectorData replyDMP = new ConnectorData();
                                replyDMP.Action = ConnectorAction.DisplayMessage;
                                replyDMP.ServerID = "NA";
                                replyDMP.Title = "AUTHENTICATION";
                                replyDMP.Content = "Code:" + printer.AuthCode + "<br /><br />Printer S/N: " + printer.Serial;
                                return new List<string> { ConnectorDataReturn(replyConnData), ConnectorDataReturn(replyDMP) };
                            }
                        }
                        else
                        {
                            var printerSN = db.Printers.Where(x => x.Serial.Trim().ToUpper() == connData.Serial.Trim().ToUpper()).FirstOrDefault();
                            //&& x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper())).FirstOrDefault();

                            ConnectorData replyConnData = new ConnectorData();
                            replyConnData.Action = ConnectorAction.RegisterPrinterInfo;

                            if (printerSN != null)
                            {
                                printerSN.Model = connData.Model.ToUpper().Contains("SATO ") ? connData.Model : "SATO " + connData.Model;
                                printerSN.MACAddress = connData.MACAddress.ToUpper();
                                printerSN.Firmware = connData.Firmware;
                                printerSN.Registered = true;
                                printerSN.Active = true;
                                printerSN.UpdatedDT = DateTime.UtcNow;
                                printerSN.UpdatedBy = "WSConnector";
                                db.SaveChanges();
                                replyConnData.Result = "REGISTERED";
                                return new List<string> { ConnectorDataReturn(replyConnData) };
                            }
                            else
                            {
                                string authCode = null;
                                while (true)
                                {
                                    authCode = RandomNumber(0, 9999).ToString("0000");
                                    var exist = db.Printers.Where(x => x.Model.Trim().ToUpper().Contains(connData.Model.Trim().ToUpper()) && x.AuthCode == authCode).FirstOrDefault();
                                    if (exist == null)
                                        break;
                                }

                                var prnt = new Printer();
                                prnt.MACAddress = connData.MACAddress.ToUpper();
                                prnt.Firmware = connData.Firmware;
                                prnt.Model = connData.Model.ToUpper().Contains("SATO ") ? connData.Model : "SATO " + connData.Model;
                                prnt.Serial = connData.Serial;
                                prnt.Registered = false;
                                prnt.Active = true;
                                prnt.AuthCode = authCode;
                                prnt.CreatedDT = DateTime.UtcNow;
                                prnt.CreatedBy = "WSConnector";

                                db.Printers.Add(prnt);
                                db.SaveChanges();
                                replyConnData.Result = "AUTHENTICATION";

                                ConnectorData replyDMP = new ConnectorData();
                                replyDMP.Action = ConnectorAction.DisplayMessage;
                                replyDMP.ServerID = "NA";
                                replyDMP.Title = "AUTHENTICATION";
                                replyDMP.Content = "Code: " + prnt.AuthCode + "<br /><br />Printer S/N: " + prnt.Serial;
                                return new List<string> { ConnectorDataReturn(replyConnData), ConnectorDataReturn(replyDMP) };
                            }
                        }
                    }
                }
                else
                {
                    Service.log.Error("Connection not found or MAC Address missing");
                }
            }
            else if (connData.Action.ToUpper() == ConnectorAction.SendCommand || connData.Action.ToUpper() == ConnectorAction.UpdatePackage)
            {
                if (connData.ServerID != null)
                {
                    if (Sessions.IDs.Where(x => x == connData.ServerID).FirstOrDefault() != null)
                        Sessions.SendTo(connData.Result, connData.ServerID);
                }
            }
            else if (connData.Action.ToUpper() == ConnectorAction.GetPrinterStatus
                  || connData.Action.ToUpper() == ConnectorAction.GetResendPrinterStatus
                  || connData.Action.ToUpper() == ConnectorAction.SendPrintCommand
                  || connData.Action.ToUpper() == ConnectorAction.ResendPrintCommand)
            {
                if (Sessions.IDs.Where(x => x == connData.ServerID).FirstOrDefault() != null)
                {
                    if (connData.Result != null)
                        Sessions.SendTo(connData.Result, connData.ServerID);
                    else
                    {
                        if (connData.DataSize == Convert.FromBase64String(connData.Data).Length.ToString())
                        {
                            Sessions.SendTo(connData.Data, connData.ServerID);
                        }
                        else
                        {
                            Service.log.Error("Data size mismatch");
                            Sessions.SendTo(ReturnVal.BadRequest, connData.ServerID);
                        }
                    }
                }
            }
            else if (connData.Action.ToUpper() == ConnectorAction.DisplayMessage)
            {
                // do nothing as API not need this status
            }
            else
            {
                Service.log.Error("Action not define/register");
            }
            return null;
        }

        protected override void OnOpen()
        {
            EmitOnPing = true;
            if (WSClients.Count == 0)
                LastSeenTimer(true);

            sess = Sessions;
            WSClients.Add(ID, new WSClientInfo());
            base.OnOpen();
        }

        protected override void OnClose(CloseEventArgs e)
        {
            WSClients.Remove(ID);
            if (WSClients.Count == 0)
                LastSeenTimer(false);

            base.OnClose(e);
        }

        protected override void OnError(ErrorEventArgs e)
        {
            string exceptStr = JsonConvert.SerializeObject(e, Formatting.None, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore
            });
            Service.log.Info(string.Format("OnError {0}", exceptStr));
            base.OnError(e);
        }

        public static void LastSeenTimer(bool start)
        {
            if (start)
            {
                LSTimer = new System.Timers.Timer();
                LSTimer.Elapsed += new System.Timers.ElapsedEventHandler(LastSeenCheck);
                LSTimer.Interval = 1000;
                LSTimer.Start();
            }
            else
            {
                LSTimer.Elapsed -= LastSeenCheck;
                LSTimer.Stop();
                LSTimer = null;
            }
        }

        private static void LastSeenCheck(object sender, System.Timers.ElapsedEventArgs e)
        {
            var connIds = WSClients.Where(x => x.Value.Active == true && DateTime.UtcNow.Subtract(x.Value.LastSeen).TotalSeconds > 120).Select(p => p.Key).ToList();
            if (connIds != null && connIds.Count > 0)
            {
                foreach (var connId in connIds)
                {
                    WSClients[connId].Active = false;
                    if (sess != null)
                        sess.CloseSession(connId);
                }
            }
        }

        private static int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        private static string ConnectorDataReturn(ConnectorData obj)
        {
            string json = JsonConvert.SerializeObject(obj, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });
            return json;
        }

        private static string JsonObjReturn(object obj)
        {
            var returnStr = JsonConvert.SerializeObject(obj, Formatting.None, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore
            });
            return returnStr;
        }

        private class WSClientInfo
        {
            public DateTime LastSeen { get; set; }
            public PrinterInfo Printer { get; set; }
            public bool Active { get; set; }

            public WSClientInfo()
            {
                LastSeen = DateTime.UtcNow;
                Printer = null;
                Active = true;
            }
        }

        private class ConnectorData
        {
            public string WebAPIServer { get; set; }
            public string DataType { get; set; }
            public string SendToMAC { get; set; }
            public string Action { get; set; }
            public string ServerID { get; set; }
            public string Model { get; set; }
            public string Serial { get; set; }
            public string Firmware { get; set; }
            public string MACAddress { get; set; }
            public string TimeOut { get; set; }
            public string DataSize { get; set; }
            public string Data { get; set; }
            public string MessageSize { get; set; }
            public string Message { get; set; }
            public string PKGSize { get; set; }
            public string PKGData { get; set; }
            public string Title { get; set; }
            public string Content { get; set; }
            public string ErrorCode { get; set; }
            public string Result { get; set; }
            public string AuthCode { get; set; }
            public string PrintSpoolerId { get; set; }
            public string PrinterName { get; set; }
            public string DocumentName { get; set; }
            public byte[] PrintData { get; set; }
            public string PrintDataSize { get; set; }
            //public bool IsPrintSpoolerEnable { get; set; }
            //public int ResendPrintJobTimer { get; set; }
        }

        private class PrinterInfo
        {
            public string Model { get; set; }
            public string Firmware { get; set; }
            public string Serial { get; set; }
            public string MacAddress { get; set; }
        }

        private class ReturnVal
        {
            public static string Accepted = "202";
            public static string BadRequest = "400";
            public static string ServiceUnavailable = "503";
        }

        private class ConnectorAction
        {
            public static string RegisterPrinterInfo = "RPI";
            public static string SendCommand = "SCP";
            public static string SendPrintCommand = "SPC";
            public static string ResendPrintCommand = "RSPC";

            public static string DisplayMessage = "DMP";
            public static string UpdatePackage = "UAP";
            public static string GetPrinterStatus = "GSP";
            public static string GetResendPrinterStatus = "GLSP";

            public static string RegisterDevice = "WRD";
            public static string DeregisterDevice = "WDD";
            public static string DeleteRegisterDevice = "DRD";

            //public static string GetRegisterDevice = "GRD";
            //public static string GetPrinterModel = "GPM";
            //public static string AddPrintSpooler = "APS";
            //public static string DeletePrintSpooler = "DPS";
            //public static string GetPrintSpooler = "GPS";
        }
    }
}
