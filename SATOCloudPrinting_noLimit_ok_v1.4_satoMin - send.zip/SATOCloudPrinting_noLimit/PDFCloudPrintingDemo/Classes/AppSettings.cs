﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFCloudPrintingDemo.Classes
{
    public class AppSettings
    {
        public string ServerURL { get; set; }
        public string MACAddress { get; set; }
    }
}