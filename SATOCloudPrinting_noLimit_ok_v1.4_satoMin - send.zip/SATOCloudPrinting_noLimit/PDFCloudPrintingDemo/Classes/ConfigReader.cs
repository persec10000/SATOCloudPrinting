﻿using System;
using System.Collections.Specialized;
using System.Configuration;

namespace PDFCloudPrintingDemo.Classes
{ 
    public class ConfigReader : IDisposable
    {
        public ConfigReader() { }

        public string GetConfigValue(string p_strConfigSection, string p_strConfigKey)
        {
            string l_strReturnResult = "";

            NameValueCollection l_oValueCollection = ConfigurationManager.GetSection(p_strConfigSection)
                as NameValueCollection;

            if (l_oValueCollection != null)
                l_strReturnResult = l_oValueCollection[p_strConfigKey];

            return l_strReturnResult;
        }

        protected static int GetConfigValue(string p_strConfigSection, string p_strConfigKey, int p_intDefaultValue)
        {
            NameValueCollection l_oValueCollection = ConfigurationManager.GetSection(p_strConfigSection) as NameValueCollection;
            if (l_oValueCollection != null)
            {
                int l_intValue = 0;
                try
                {
                    l_intValue = int.Parse(l_oValueCollection[p_strConfigKey]);
                }
                catch
                {
                }
                return l_intValue;
            }
            return p_intDefaultValue;
        }

        public static int LoginRetry
        {
            get
            {
                return ConfigReader.GetConfigValue("AppConfig", "LoginRetry", 3);
            }
        }


        public void Dispose() { }
    }
}