﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFCloudPrintingDemo.SessionModels
{
    public interface ISessionWrapper
    {
        string loginUserName { get; set; }
    }
}