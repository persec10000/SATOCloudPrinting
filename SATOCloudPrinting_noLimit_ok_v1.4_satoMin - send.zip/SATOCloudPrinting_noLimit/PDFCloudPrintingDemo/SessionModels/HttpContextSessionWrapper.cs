﻿using System.Web;

namespace PDFCloudPrintingDemo.SessionModels
{
    public class HttpContextSessionWrapper : ISessionWrapper
    {
        private T GetFromSession<T>(string key)
        {
            return (T)HttpContext.Current.Session[key];
        }

        private void SetInSession(string key, object value)
        {
            HttpContext.Current.Session[key] = value;
        }

        public string loginUserName
        {
            get { return GetFromSession<string>("loginUserName"); }
            set { SetInSession("loginUserName", value); }
        }
    }
}