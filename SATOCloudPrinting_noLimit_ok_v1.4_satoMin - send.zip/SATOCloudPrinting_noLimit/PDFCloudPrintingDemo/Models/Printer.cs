﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PDFCloudPrintingDemo.Models
{
    public class Printer
    {
        public string Id { get; set; }
        public string PrinterName { get; set; }
        public string Model { get; set; }
        public string Firmware { get; set; }
        public string Serial { get; set; }
        public string MACAddress { get; set; }
        public string AuthCode { get; set; }
        public string Registered { get; set; }
        public string Connected { get; set; }
        public string Active { get; set; }
        public string CreatedDT { get; set; }
        public string UpdatedDT { get; set; }
        public string CreatedBy { get; set; }
        public string UpdatedBy { get; set; }
    }
}